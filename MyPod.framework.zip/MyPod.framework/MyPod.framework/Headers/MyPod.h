//
//  MyPod.h
//  MyPod
//
//  Created by Martin Tyberg on 11/7/17.
//  Copyright © 2017 MapText. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MyPod.
FOUNDATION_EXPORT double MyPodVersionNumber;

//! Project version string for MyPod.
FOUNDATION_EXPORT const unsigned char MyPodVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyPod/PublicHeader.h>


